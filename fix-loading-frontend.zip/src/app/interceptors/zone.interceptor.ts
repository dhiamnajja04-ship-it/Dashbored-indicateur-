import { HttpInterceptorFn } from '@angular/common/http';
import { NgZone, inject } from '@angular/core';
import { Observable } from 'rxjs';

/**
 * Force chaque réponse HTTP à être ré-émise à l'intérieur de la zone Angular.
 *
 * Bug connu : le backend Fetch de HttpClient (utilisé par défaut par cette
 * version d'Angular) résout ses promesses en dehors de la zone patchée par
 * zone.js. Sans ce correctif, un composant qui fait `this.loading = false`
 * dans un callback `next()` ne déclenche jamais de nouveau cycle de
 * détection de changements : la donnée est bien arrivée (visible dans
 * l'onglet Network), mais l'écran reste figé sur "Chargement...".
 */
export const zoneInterceptor: HttpInterceptorFn = (req, next) => {
  const zone = inject(NgZone);
  return new Observable((subscriber) => {
    const subscription = next(req).subscribe({
      next: (event) => zone.run(() => subscriber.next(event)),
      error: (err) => zone.run(() => subscriber.error(err)),
      complete: () => zone.run(() => subscriber.complete()),
    });
    return () => subscription.unsubscribe();
  });
};

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MetierService.Data;
using MetierService.Models;
using Npgsql;

namespace MetierService.Controllers
{
    [Route("api/indicators")]
    [ApiController]
    public class IndicatorsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<IndicatorsController> _logger;

        public IndicatorsController(AppDbContext context, ILogger<IndicatorsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/indicators
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Indicateur>>> GetIndicateurs()
        {
            return await _context.Indicateurs.Include(i => i.ValeursIndicateurs).ToListAsync();
        }

        // GET: api/indicators/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Indicateur>> GetIndicateur(int id)
        {
            var indicateur = await _context.Indicateurs
                .Include(i => i.ValeursIndicateurs)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (indicateur == null) return NotFound(new { message = "Indicateur introuvable." });
            return indicateur;
        }

        // POST: api/indicators
        [HttpPost]
        public async Task<ActionResult<Indicateur>> PostIndicateur(Indicateur indicateur)
        {
            _context.Indicateurs.Add(indicateur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return HandleDbUpdateException(ex, $"le code « {indicateur.Code} »");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la création d'un indicateur");
                return StatusCode(500, new { message = "Erreur interne lors de la création de l'indicateur." });
            }
            return CreatedAtAction(nameof(GetIndicateur), new { id = indicateur.Id }, indicateur);
        }

        // PUT: api/indicators/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIndicateur(int id, Indicateur indicateur)
        {
            if (id != indicateur.Id)
                return BadRequest(new { message = "L'identifiant de l'URL ne correspond pas à celui de l'indicateur." });

            _context.Entry(indicateur).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                var exists = await _context.Indicateurs.AnyAsync(i => i.Id == id);
                if (!exists) return NotFound(new { message = "Cet indicateur n'existe plus." });
                throw;
            }
            catch (DbUpdateException ex)
            {
                return HandleDbUpdateException(ex, $"le code « {indicateur.Code} »");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la mise à jour d'un indicateur");
                return StatusCode(500, new { message = "Erreur interne lors de la mise à jour de l'indicateur." });
            }
            return NoContent();
        }

        // DELETE: api/indicators/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteIndicateur(int id)
        {
            var indicateur = await _context.Indicateurs.FindAsync(id);
            if (indicateur == null) return NotFound(new { message = "Indicateur introuvable." });

            _context.Indicateurs.Remove(indicateur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la suppression d'un indicateur");
                return StatusCode(500, new { message = "Erreur interne lors de la suppression de l'indicateur." });
            }
            return NoContent();
        }

        // --- GESTION DES VALEURS (Page Consulter / Saisie / Validation Admin) ---

        // GET: api/indicators/5/valeurs
        [HttpGet("{id}/valeurs")]
        public async Task<ActionResult<IEnumerable<ValeurIndicateur>>> GetValeurs(int id)
        {
            return await _context.ValeursIndicateurs.Where(v => v.IndicateurId == id).ToListAsync();
        }

        // POST: api/indicators/5/valeurs (Saisie par un utilisateur)
        [HttpPost("{id}/valeurs")]
        public async Task<ActionResult<ValeurIndicateur>> PostValeur(int id, ValeurIndicateur valeur)
        {
            var indicateurExiste = await _context.Indicateurs.AnyAsync(i => i.Id == id);
            if (!indicateurExiste) return NotFound(new { message = "Indicateur introuvable." });

            valeur.IndicateurId = id;
            valeur.SaisieLe = DateTime.UtcNow;
            valeur.IsValid = false; // Par défaut non validé
            _context.ValeursIndicateurs.Add(valeur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return HandleDbUpdateException(ex, "cette valeur");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la création d'une valeur");
                return StatusCode(500, new { message = "Erreur interne lors de la création de la valeur." });
            }
            return Ok(valeur);
        }

        // PUT: api/indicators/values/5 (Modifier une valeur)
        [HttpPut("values/{valueId}")]
        public async Task<IActionResult> PutValeur(int valueId, ValeurIndicateur valeur)
        {
            if (valueId != valeur.Id)
                return BadRequest(new { message = "L'identifiant de l'URL ne correspond pas à celui de la valeur." });

            valeur.UpdateAt = DateTime.UtcNow;
            _context.Entry(valeur).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                var exists = await _context.ValeursIndicateurs.AnyAsync(v => v.Id == valueId);
                if (!exists) return NotFound(new { message = "Cette valeur n'existe plus." });
                throw;
            }
            catch (DbUpdateException ex)
            {
                return HandleDbUpdateException(ex, "cette valeur");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la mise à jour d'une valeur");
                return StatusCode(500, new { message = "Erreur interne lors de la mise à jour de la valeur." });
            }
            return NoContent();
        }

        // PUT: api/indicators/values/5/valider (Validation par l'administrateur)
        [HttpPut("values/{valueId}/valider")]
        public async Task<IActionResult> ValiderValeur(int valueId, [FromBody] string adminNom)
        {
            var valeur = await _context.ValeursIndicateurs.FindAsync(valueId);
            if (valeur == null) return NotFound(new { message = "Cette valeur n'existe pas." });

            valeur.IsValid = true;
            valeur.ValidePar = adminNom ?? "Admin";
            valeur.Statut = "Validé";
            valeur.UpdateAt = DateTime.UtcNow;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la validation d'une valeur");
                return StatusCode(500, new { message = "Erreur interne lors de la validation de la valeur." });
            }
            return NoContent();
        }

        // DELETE: api/indicators/values/5 (Supprimer une valeur)
        [HttpDelete("values/{valueId}")]
        public async Task<IActionResult> DeleteValeur(int valueId)
        {
            var valeur = await _context.ValeursIndicateurs.FindAsync(valueId);
            if (valeur == null) return NotFound(new { message = "Cette valeur n'existe pas." });

            _context.ValeursIndicateurs.Remove(valeur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur inattendue lors de la suppression d'une valeur");
                return StatusCode(500, new { message = "Erreur interne lors de la suppression de la valeur." });
            }
            return NoContent();
        }

        /// <summary>
        /// Traduit les erreurs PostgreSQL courantes (contrainte unique, clé étrangère, champ
        /// obligatoire manquant) en réponse HTTP lisible par le frontend, au lieu de laisser
        /// remonter un 500 brut avec la stack trace complète.
        /// </summary>
        private ActionResult HandleDbUpdateException(DbUpdateException ex, string contexte)
        {
            _logger.LogError(ex, "Erreur de mise à jour en base de données");

            if (ex.InnerException is PostgresException pgEx)
            {
                switch (pgEx.SqlState)
                {
                    case "23505": // unique_violation
                        return Conflict(new
                        {
                            message = $"Un enregistrement avec {contexte} existe déjà. Merci d'utiliser une valeur différente."
                        });
                    case "23503": // foreign_key_violation
                        return BadRequest(new
                        {
                            message = "Référence invalide : la catégorie, l'organisation ou la période indiquée n'existe pas."
                        });
                    case "23502": // not_null_violation
                        return BadRequest(new
                        {
                            message = $"Un champ obligatoire est manquant ({pgEx.ColumnName})."
                        });
                }
            }

            return StatusCode(500, new { message = "Erreur lors de l'enregistrement en base de données." });
        }
    }
}

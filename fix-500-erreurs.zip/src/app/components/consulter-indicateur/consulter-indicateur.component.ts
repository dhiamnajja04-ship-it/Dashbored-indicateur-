import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { IndicateurService, Indicateur, ValeurIndicateur } from '../../services/indicateur.service';

@Component({
  selector: 'app-consulter-indicateur',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './consulter-indicateur.component.html',
})
export class ConsulterIndicateurComponent implements OnInit {
  indicateur: any = null;
  valeurs: any[] = [];
  indicateurId!: number;
  erreur = '';

  afficherFormulaireValeur = false;
  modeEditionValeur = false;
  valeurCourante: Partial<ValeurIndicateur> = this.valeurVide();

  // Empêche le double-clic et affiche une erreur lisible si l'enregistrement échoue.
  enregistrementEnCours = false;
  erreurFormulaire = '';

  constructor(
    private route: ActivatedRoute,
    private indicateurService: IndicateurService,
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.indicateurId = +idParam;
      this.chargerDetails();
    }
  }

  chargerDetails() {
    this.indicateurService.getById(this.indicateurId).subscribe({
      next: (data) => {
        this.indicateur = data;
        this.valeurs = data.valeursIndicateurs || (data as any).ValeursIndicateurs || [];
      },
      error: (err) => {
        console.error('Erreur lors du chargement', err);
        this.erreur = "Impossible de charger cet indicateur. Vérifie que le Gateway et le service métier sont démarrés.";
      },
    });
  }

  private valeurVide(): Partial<ValeurIndicateur> {
    return {
      indicateurId: this.indicateurId,
      organisationId: 1,
      periodeId: 1,
      valeur: 0,
      degreDeFiabilite: '',
      commentaire: '',
      saisiePar: '',
    };
  }

  private messageErreur(err: HttpErrorResponse): string {
    if (err.error && typeof err.error === 'object' && err.error.message) {
      return err.error.message;
    }
    if (err.status === 0) {
      return "Impossible de contacter le serveur. Vérifie que le Gateway et le service métier sont démarrés.";
    }
    return `Une erreur est survenue (code ${err.status}). Réessaie ou vérifie les données saisies.`;
  }

  ouvrirCreationValeur() {
    this.modeEditionValeur = false;
    this.valeurCourante = this.valeurVide();
    this.erreurFormulaire = '';
    this.afficherFormulaireValeur = true;
  }

  ouvrirEditionValeur(val: ValeurIndicateur) {
    this.modeEditionValeur = true;
    this.valeurCourante = { ...val };
    this.erreurFormulaire = '';
    this.afficherFormulaireValeur = true;
  }

  annulerFormulaireValeur() {
    this.afficherFormulaireValeur = false;
    this.erreurFormulaire = '';
  }

  enregistrerValeur() {
    if (this.enregistrementEnCours) return; // évite le double-submit
    this.enregistrementEnCours = true;
    this.erreurFormulaire = '';

    if (this.modeEditionValeur && this.valeurCourante.id) {
      this.indicateurService.modifierValeur(this.valeurCourante as ValeurIndicateur).subscribe({
        next: () => {
          this.enregistrementEnCours = false;
          this.afficherFormulaireValeur = false;
          this.chargerDetails();
        },
        error: (err: HttpErrorResponse) => {
          console.error('Erreur lors de la mise à jour de la valeur', err);
          this.enregistrementEnCours = false;
          this.erreurFormulaire = this.messageErreur(err);
        },
      });
    } else {
      this.indicateurService.creerValeur(this.indicateurId, this.valeurCourante).subscribe({
        next: () => {
          this.enregistrementEnCours = false;
          this.afficherFormulaireValeur = false;
          this.chargerDetails();
        },
        error: (err: HttpErrorResponse) => {
          console.error('Erreur lors de la création de la valeur', err);
          this.enregistrementEnCours = false;
          this.erreurFormulaire = this.messageErreur(err);
        },
      });
    }
  }

  valider(valueId: number) {
    this.indicateurService.validerValeur(valueId, 'Administrateur', 'Validé').subscribe({
      next: () => this.chargerDetails(),
      error: (err: HttpErrorResponse) => {
        console.error('Erreur validation', err);
        this.erreur = this.messageErreur(err);
      },
    });
  }

  supprimerValeur(valueId: number) {
    if (confirm('Voulez-vous supprimer cette valeur ?')) {
      this.indicateurService.supprimerValeur(valueId).subscribe({
        next: () => this.chargerDetails(),
        error: (err: HttpErrorResponse) => {
          console.error('Erreur suppression', err);
          this.erreur = this.messageErreur(err);
        },
      });
    }
  }
}
